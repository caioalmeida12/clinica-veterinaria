package entidades;

public class Funcionario {
  private Integer cpf;
  private String nome;
  private Integer telefone;
  private String email;
  private Integer salario;
}